// Common visual primitives for the MOSUN EPK animation.
// Colors, saffron glow background, marks, labels, etc.

const MOSUN_INK = '#000000';
const MOSUN_CREAM = '#E8E6D9';
const MOSUN_SAFFRON = '#F6A25C';
const MOSUN_SAFFRON_DEEP = '#B8661F';
const MOSUN_OXBLOOD = '#7E0101';
const MOSUN_FOREST = '#486348';
const MOSUN_CREAM_80 = '#B9B7AC';
const MOSUN_CREAM_60 = '#8A8880';
const MOSUN_CREAM_40 = '#5C5B55';

const FONT_DISPLAY = "'Prospec', 'Rosnoc', Georgia, serif";
const FONT_DECOR = "'Rosnoc', 'Prospec', Georgia, serif";
const FONT_SANS = "'Futura', 'Futura PT', 'Trebuchet MS', 'Century Gothic', Avenir, -apple-system, sans-serif";
const FONT_SERIF = "'Cormorant Garamond', Georgia, serif";

// A flickering, breathing saffron glow that lives the whole video.
// Sits at a chosen x/y with a given radius; intensity breathes via time.
function SaffronGlow({ x = 960, y = 540, radius = 900, intensity = 0.18, hue = MOSUN_SAFFRON }) {
  const time = useTime();
  // Slow breathing + occasional subtle flicker
  const breath = 0.85 + 0.15 * Math.sin(time * 0.6);
  const flicker = (Math.sin(time * 13.2) * 0.02) + (Math.sin(time * 7.1) * 0.015);
  const a = clamp(intensity * breath + flicker, 0, 0.45);
  return (
    <div style={{
      position: 'absolute',
      left: x - radius,
      top: y - radius,
      width: radius * 2,
      height: radius * 2,
      borderRadius: '50%',
      background: `radial-gradient(circle at center, ${hue}${Math.round(a * 255).toString(16).padStart(2,'0')} 0%, transparent 60%)`,
      pointerEvents: 'none',
      willChange: 'opacity',
      mixBlendMode: 'screen',
    }}/>
  );
}

// Grainy film overlay — subtle noise feel for warm candlelit look.
function GrainOverlay({ opacity = 0.05 }) {
  return (
    <div style={{
      position: 'absolute', inset: 0,
      pointerEvents: 'none',
      opacity,
      backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='240' height='240'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%' height='100%' filter='url(%23n)' opacity='0.6'/></svg>")`,
      mixBlendMode: 'overlay',
    }}/>
  );
}

// Persistent chrome: tiny wordmark in top-left, section label in top-right,
// timecode-like meta in bottom-right, saffron dot + 'EPK · 2026' bottom-left.
function Chrome({ section = '', sectionNo = '', total = '06' }) {
  return (
    <>
      {/* Top-left: MOSUN lockup */}
      <div style={{
        position: 'absolute', top: 36, left: 48,
        fontFamily: FONT_DISPLAY,
        fontSize: 16, letterSpacing: '0.32em',
        color: MOSUN_CREAM,
        textTransform: 'uppercase',
      }}>
        MOSUN
      </div>
      {/* Top-right: section label */}
      <div style={{
        position: 'absolute', top: 36, right: 48,
        fontFamily: FONT_SANS,
        fontSize: 11, letterSpacing: '0.24em',
        color: MOSUN_CREAM_60,
        textTransform: 'uppercase',
        display: 'flex', gap: 12, alignItems: 'center',
      }}>
        {sectionNo && (
          <>
            <span style={{ color: MOSUN_SAFFRON }}>{sectionNo}</span>
            <span style={{ width: 18, height: 1, background: MOSUN_CREAM_40 }}/>
          </>
        )}
        <span>{section}</span>
      </div>
      {/* Bottom-left: EPK meta */}
      <div style={{
        position: 'absolute', bottom: 36, left: 48,
        fontFamily: FONT_SANS,
        fontSize: 11, letterSpacing: '0.24em',
        color: MOSUN_CREAM_60,
        textTransform: 'uppercase',
        display: 'flex', gap: 10, alignItems: 'center',
      }}>
        <span style={{ width: 5, height: 5, borderRadius: '50%', background: MOSUN_SAFFRON, display: 'inline-block' }}/>
        <span>Electronic Press Kit · 2026</span>
      </div>
      {/* Bottom-right: frame count */}
      <div style={{
        position: 'absolute', bottom: 36, right: 48,
        fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
        fontSize: 11, letterSpacing: '0.16em',
        color: MOSUN_CREAM_40,
      }}>
        {sectionNo || '—'} / {total}
      </div>
    </>
  );
}

// An eyebrow label — small tracked all-caps line, with optional saffron dot.
function Eyebrow({ children, color = MOSUN_CREAM_60, dot = true }) {
  return (
    <div style={{
      fontFamily: FONT_SANS,
      fontSize: 12,
      letterSpacing: '0.28em',
      color,
      textTransform: 'uppercase',
      display: 'inline-flex', alignItems: 'center', gap: 12,
    }}>
      {dot && <span style={{ width: 5, height: 5, borderRadius: '50%', background: MOSUN_SAFFRON, display: 'inline-block' }}/>}
      <span>{children}</span>
    </div>
  );
}

// Horizontal hairline that draws itself in.
function Hairline({ width = 240, color = `rgba(232,230,217,0.28)`, progress = 1, style = {} }) {
  return (
    <div style={{
      height: 1,
      width: width * clamp(progress, 0, 1),
      background: color,
      transition: 'width 200ms linear',
      ...style,
    }}/>
  );
}

// Text that reveals word-by-word (fades + slight rise) using local sprite progress.
// Words split on whitespace; holds punctuation with the word.
function RevealText({
  text,
  font = FONT_DISPLAY,
  size = 96,
  color = MOSUN_CREAM,
  weight = 400,
  letterSpacing = '-0.01em',
  lineHeight = 1.05,
  staggerMs = 80,      // ms between words
  entryDur = 600,      // per-word fade-in duration (ms)
  startAt = 0,         // local seconds to start revealing
  style = {},
}) {
  const { localTime } = useSprite();
  const words = text.split(/\s+/);
  const tMs = Math.max(0, (localTime - startAt) * 1000);

  return (
    <div style={{
      fontFamily: font,
      fontSize: size,
      color,
      fontWeight: weight,
      letterSpacing,
      lineHeight,
      display: 'inline-block',
      ...style,
    }}>
      {words.map((w, i) => {
        const wStart = i * staggerMs;
        const local = clamp((tMs - wStart) / entryDur, 0, 1);
        const eased = Easing.easeOutCubic(local);
        return (
          <span key={i} style={{
            display: 'inline-block',
            opacity: eased,
            transform: `translateY(${(1 - eased) * 14}px)`,
            marginRight: '0.28em',
            willChange: 'transform, opacity',
          }}>
            {w}
          </span>
        );
      })}
    </div>
  );
}

// Fade wrapper — fades children in/out based on in/out seconds.
function Fade({ in_ = 0.4, out = 0.4, children, style = {} }) {
  const { localTime, duration } = useSprite();
  const exitStart = Math.max(0, duration - out);
  let op = 1;
  if (localTime < in_) op = Easing.easeOutCubic(clamp(localTime / in_, 0, 1));
  else if (localTime > exitStart) op = 1 - Easing.easeInCubic(clamp((localTime - exitStart) / out, 0, 1));
  return <div style={{ opacity: op, ...style }}>{children}</div>;
}

// Photo placeholder — a warm candlelit frame with a film-cross marker,
// a handwritten-feel slug, and a subtle grain. Sized by w/h props; pass
// `label` to change the slug and `variant` for portrait/landscape feel.
function PhotoPlaceholder({
  w = 400, h = 500,
  label = 'PHOTO',
  sub = '',
  radius = 0,
  rotate = 0,
  style = {},
}) {
  return (
    <div style={{
      width: w, height: h,
      position: 'relative',
      borderRadius: radius,
      overflow: 'hidden',
      transform: `rotate(${rotate}deg)`,
      background: `
        linear-gradient(135deg, rgba(246,162,92,0.22), rgba(126,1,1,0.18) 55%, rgba(0,0,0,0.6)),
        radial-gradient(ellipse at 30% 30%, rgba(246,162,92,0.35), transparent 60%),
        #0b0b0b
      `,
      border: '1px solid rgba(232,230,217,0.22)',
      boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
      ...style,
    }}>
      {/* Crosshair */}
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{
        position: 'absolute', inset: 0, width: '100%', height: '100%',
        opacity: 0.3,
      }}>
        <line x1="0" y1="0" x2="100" y2="100" stroke="#E8E6D9" strokeWidth="0.2"/>
        <line x1="100" y1="0" x2="0" y2="100" stroke="#E8E6D9" strokeWidth="0.2"/>
      </svg>
      {/* Corner brackets */}
      {[
        { top: 12, left: 12, r: '0 0 0 0' },
        { top: 12, right: 12, r: '0 0 0 0' },
        { bottom: 12, left: 12, r: '0 0 0 0' },
        { bottom: 12, right: 12, r: '0 0 0 0' },
      ].map((c, i) => (
        <div key={i} style={{
          position: 'absolute', ...c,
          width: 22, height: 22,
          borderTop: i < 2 ? `1.5px solid ${MOSUN_SAFFRON}` : 'none',
          borderBottom: i >= 2 ? `1.5px solid ${MOSUN_SAFFRON}` : 'none',
          borderLeft: (i === 0 || i === 2) ? `1.5px solid ${MOSUN_SAFFRON}` : 'none',
          borderRight: (i === 1 || i === 3) ? `1.5px solid ${MOSUN_SAFFRON}` : 'none',
        }}/>
      ))}
      {/* Center slug */}
      <div style={{
        position: 'absolute', left: '50%', top: '50%',
        transform: 'translate(-50%, -50%)',
        textAlign: 'center',
      }}>
        <div style={{
          fontFamily: FONT_SANS, fontSize: 10,
          letterSpacing: '0.32em', textTransform: 'uppercase',
          color: 'rgba(232,230,217,0.6)', marginBottom: 10,
        }}>Photo Placeholder</div>
        <div style={{
          fontFamily: FONT_DISPLAY, fontSize: Math.min(40, w / 10),
          letterSpacing: '0.06em', color: MOSUN_CREAM,
          textTransform: 'uppercase', lineHeight: 1.1,
        }}>{label}</div>
        {sub && <div style={{
          fontFamily: FONT_SERIF, fontStyle: 'italic',
          fontSize: 14, color: 'rgba(232,230,217,0.7)',
          marginTop: 10,
        }}>{sub}</div>}
      </div>
      {/* Meta stripe bottom */}
      <div style={{
        position: 'absolute', left: 14, bottom: 14, right: 14,
        display: 'flex', justifyContent: 'space-between',
        fontFamily: 'ui-monospace, monospace', fontSize: 9,
        letterSpacing: '0.2em', color: 'rgba(232,230,217,0.5)',
        textTransform: 'uppercase',
      }}>
        <span>MOSUN · 2026</span>
        <span>REF · {Math.abs(label.length * 137 % 9999).toString().padStart(4, '0')}</span>
      </div>
    </div>
  );
}

Object.assign(window, {
  MOSUN_INK, MOSUN_CREAM, MOSUN_SAFFRON, MOSUN_SAFFRON_DEEP,
  MOSUN_OXBLOOD, MOSUN_FOREST, MOSUN_CREAM_80, MOSUN_CREAM_60, MOSUN_CREAM_40,
  FONT_DISPLAY, FONT_DECOR, FONT_SANS, FONT_SERIF,
  SaffronGlow, GrainOverlay, Chrome, Eyebrow, Hairline, RevealText, Fade,
  PhotoPlaceholder,
});
