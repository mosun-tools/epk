// Scene 1 — Cold open: saffron glow, wordmark materializes.
// Scene 2 — Bio: name, roles, Taipei↔LA, Grammy voting member.
// Scene 3 — Sound: genre tags collide into one line.

// ─────────────────────────────────────────────────────────────
// SCENE 1 — Cold Open  (0 → 5s)
// ─────────────────────────────────────────────────────────────
function SceneOpen({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      {({ localTime, duration }) => {
        const t = localTime;
        // Glow fade in
        const glowOp = Easing.easeOutCubic(clamp(t / 1.4, 0, 1));
        // Wordmark: flicker on at ~0.6s, settle by 1.8s
        const wmStart = 0.6;
        const wmLocal = Math.max(0, t - wmStart);
        const flickerFrames = [0, 0.08, 0.14, 0.18, 0.24, 0.32];
        let wmOp = 0;
        if (wmLocal < 0.4) {
          // Flicker: on/off/on pattern
          const steps = [0, 1, 0.2, 1, 0.5, 1];
          const idx = Math.min(steps.length - 1, Math.floor(wmLocal / 0.07));
          wmOp = steps[idx];
        } else {
          wmOp = 1;
        }
        // Tracking expands from 0.14 to 0.32em during settle (1.0 → 2.2s)
        const tr = interpolate([1.0, 2.2], [0.14, 0.32], Easing.easeOutCubic)(t);
        // Caption fade at 2.4s, hairline draws 3.0s
        const capOp = Easing.easeOutCubic(clamp((t - 2.4) / 0.9, 0, 1));
        const lineProg = Easing.easeOutCubic(clamp((t - 3.0) / 1.2, 0, 1));
        // Exit: full fade in last 0.5s
        const exitStart = duration - 0.5;
        const fade = t > exitStart ? 1 - Easing.easeInCubic((t - exitStart) / 0.5) : 1;

        return (
          <div style={{ position: 'absolute', inset: 0, opacity: fade }}>
            <div style={{ position: 'absolute', inset: 0, opacity: glowOp }}>
              <SaffronGlow x={960} y={540} radius={1000} intensity={0.22}/>
            </div>

            {/* Giant faint mark watermark */}
            <div style={{
              position: 'absolute', left: '50%', top: '50%',
              transform: `translate(-50%, -50%) scale(${1 + 0.04 * Easing.easeOutCubic(clamp(t/3, 0, 1))})`,
              opacity: 0.05 * glowOp,
              pointerEvents: 'none',
            }}>
              <img src="assets/mark-cream-on-black.png" style={{ width: 1400, height: 'auto' }}/>
            </div>

            {/* Wordmark center */}
            <div style={{
              position: 'absolute', left: '50%', top: '50%',
              transform: 'translate(-50%, -50%)',
              textAlign: 'center',
            }}>
              <div style={{
                fontFamily: FONT_DISPLAY,
                fontSize: 180,
                color: MOSUN_CREAM,
                letterSpacing: `${tr}em`,
                textTransform: 'uppercase',
                opacity: wmOp,
                textShadow: `0 0 60px rgba(246,162,92,${0.18 * wmOp})`,
                paddingLeft: `${tr * 180}px`, // compensate for tracking
              }}>
                MOSUN
              </div>
              {/* Chinese name */}
              <div style={{
                fontFamily: FONT_SERIF,
                fontStyle: 'italic',
                fontSize: 28,
                color: MOSUN_CREAM_80,
                marginTop: 8,
                opacity: capOp,
                letterSpacing: '0.05em',
              }}>
                馬仕釗 · Morrison Ma
              </div>
              <div style={{
                margin: '28px auto 0',
                height: 1,
                width: 180 * lineProg,
                background: MOSUN_SAFFRON,
                opacity: 0.8,
              }}/>
              <div style={{
                fontFamily: FONT_SANS,
                fontSize: 12, letterSpacing: '0.32em',
                color: MOSUN_CREAM_60,
                textTransform: 'uppercase',
                marginTop: 20,
                opacity: clamp((t - 3.3) / 0.8, 0, 1),
              }}>
                Electronic Press Kit · 2026
              </div>
            </div>

            <GrainOverlay opacity={0.06}/>
          </div>
        );
      }}
    </Sprite>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 2 — Bio  (5 → 13s)
// ─────────────────────────────────────────────────────────────
function SceneBio({ start, end }) {
  const ROLES = ['Artist', 'Producer', 'Arranger', 'Sound Designer'];
  return (
    <Sprite start={start} end={end}>
      {({ localTime, duration }) => {
        const t = localTime;
        const exitStart = duration - 0.6;
        const pageFade = t > exitStart ? 1 - Easing.easeInCubic((t - exitStart) / 0.6) : 1;

        // Left column: name + origin
        const nameOp = Easing.easeOutCubic(clamp((t - 0.1) / 0.7, 0, 1));
        const roleSwap = Math.floor(clamp((t - 1.0) / 0.7, 0, ROLES.length - 0.001));
        const roleLocal = ((t - 1.0) / 0.7) - roleSwap;
        const roleOp = roleLocal < 0.15 ? roleLocal / 0.15
                      : roleLocal > 0.85 ? (1 - (roleLocal - 0.85) / 0.15) : 1;
        const showAllRoles = t > 1.0 + ROLES.length * 0.7; // after cycle, reveal full stack

        // Paragraph reveal
        const paraStart = 4.2;

        return (
          <div style={{ position: 'absolute', inset: 0, opacity: pageFade }}>
            <SaffronGlow x={200} y={900} radius={700} intensity={0.1}/>
            <Chrome section="Bio" sectionNo="01" total="07"/>

            {/* Portrait placeholder — far left */}
            <div style={{
              position: 'absolute', left: 120, top: 180,
              opacity: Easing.easeOutCubic(clamp((t - 0.2) / 0.8, 0, 1)),
              transform: `translateY(${(1 - Easing.easeOutCubic(clamp((t - 0.2) / 0.8, 0, 1))) * 20}px)`,
            }}>
              <div style={{
                position: 'relative', width: 460, height: 620,
                overflow: 'hidden',
                boxShadow: '0 20px 80px rgba(0,0,0,0.6), 0 0 0 1px rgba(232,230,217,0.08)',
              }}>
                <img src="assets/mosun-profile.jpg" alt="MOSUN"
                  style={{
                    width: '100%', height: '100%', objectFit: 'cover',
                    objectPosition: 'center 28%',
                    display: 'block',
                    filter: 'contrast(1.02) saturate(1.05)',
                  }}/>
                {/* saffron corner brackets */}
                {[[0,0],[1,0],[0,1],[1,1]].map(([x,y],i)=>(
                  <span key={i} style={{
                    position: 'absolute',
                    left: x ? 'auto' : 10, right: x ? 10 : 'auto',
                    top:  y ? 'auto' : 10, bottom: y ? 10 : 'auto',
                    width: 18, height: 18,
                    borderLeft:  x ? 'none' : '1.5px solid #F6A25C',
                    borderRight: x ? '1.5px solid #F6A25C' : 'none',
                    borderTop:   y ? 'none' : '1.5px solid #F6A25C',
                    borderBottom:y ? '1.5px solid #F6A25C' : 'none',
                    mixBlendMode: 'screen',
                  }}/>
                ))}
                {/* ref slug */}
                <div style={{
                  position: 'absolute', left: 14, bottom: 14,
                  fontFamily: FONT_SANS, fontSize: 10,
                  letterSpacing: '0.3em', color: '#F6A25C',
                  textTransform: 'uppercase',
                  textShadow: '0 1px 2px rgba(0,0,0,0.6)',
                }}>MOSUN · 2026</div>
                <div style={{
                  position: 'absolute', right: 14, bottom: 14,
                  fontFamily: FONT_SANS, fontSize: 10,
                  letterSpacing: '0.3em', color: 'rgba(232,230,217,0.8)',
                  textTransform: 'uppercase',
                  textShadow: '0 1px 2px rgba(0,0,0,0.6)',
                }}>01 / PORTRAIT</div>
              </div>
            </div>

            {/* Middle column */}
            <div style={{
              position: 'absolute', left: 640, top: 200,
              width: 600,
            }}>
              <div style={{ opacity: Easing.easeOutCubic(clamp((t - 0.0) / 0.5, 0, 1)) }}>
                <Eyebrow>Introduction</Eyebrow>
              </div>

              <div style={{
                marginTop: 32,
                opacity: nameOp,
                transform: `translateY(${(1 - nameOp) * 14}px)`,
              }}>
                <div style={{
                  fontFamily: FONT_DISPLAY, fontSize: 96, color: MOSUN_CREAM,
                  letterSpacing: '0.02em', textTransform: 'uppercase', lineHeight: 1,
                }}>MOSUN</div>
                <div style={{
                  fontFamily: FONT_SERIF, fontStyle: 'italic', fontSize: 34,
                  color: MOSUN_CREAM_80, marginTop: 8, letterSpacing: '0.04em',
                }}>
                  馬仕釗 · Morrison Ma
                </div>
              </div>

              {/* Role rotator or stacked list */}
              <div style={{ marginTop: 40, height: 160 }}>
                {!showAllRoles ? (
                  <div style={{
                    fontFamily: FONT_DISPLAY,
                    fontSize: 56,
                    color: MOSUN_SAFFRON,
                    letterSpacing: '-0.01em',
                    opacity: roleOp,
                    textTransform: 'uppercase',
                  }}>
                    {ROLES[clamp(roleSwap, 0, ROLES.length - 1)]}
                  </div>
                ) : (
                  <div style={{
                    fontFamily: FONT_DISPLAY,
                    fontSize: 34, lineHeight: 1.2,
                    color: MOSUN_CREAM,
                    textTransform: 'uppercase',
                    letterSpacing: '-0.005em',
                  }}>
                    {ROLES.map((r, i) => (
                      <div key={i} style={{
                        opacity: clamp((t - (1.0 + ROLES.length * 0.7) - i * 0.08) / 0.3, 0, 1),
                        transform: `translateY(${(1 - clamp((t - (1.0 + ROLES.length * 0.7) - i * 0.08) / 0.3, 0, 1)) * 10}px)`,
                        color: i === 0 ? MOSUN_SAFFRON : MOSUN_CREAM,
                      }}>
                        {r}{i < ROLES.length - 1 && <span style={{ color: MOSUN_CREAM_40 }}>  ·  </span>}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Right column — paragraph + meta */}
            <div style={{
              position: 'absolute', right: 120, top: 200,
              width: 520,
            }}>
              <Eyebrow color={MOSUN_CREAM_60}>
                <span style={{
                  opacity: Easing.easeOutCubic(clamp((t - 3.0) / 0.5, 0, 1)),
                }}>Taipei ↔ Los Angeles</span>
              </Eyebrow>

              <div style={{ marginTop: 20, opacity: clamp((t - paraStart) / 0.5, 0, 1) }}>
                <RevealText
                  text="A multi-hyphenate creator building worlds through modular synthesis and ambient texture — where R&B, electronic, and experimental collide in a late-night Mandopop aesthetic."
                  size={26}
                  font={FONT_SANS}
                  color={MOSUN_CREAM}
                  lineHeight={1.55}
                  weight={400}
                  letterSpacing="0"
                  staggerMs={55}
                  entryDur={500}
                  startAt={paraStart}
                />
              </div>

              {/* Grammy badge */}
              <div style={{
                marginTop: 64,
                opacity: Easing.easeOutCubic(clamp((t - 6.0) / 0.6, 0, 1)),
                transform: `translateY(${(1 - Easing.easeOutCubic(clamp((t - 6.0) / 0.6, 0, 1))) * 10}px)`,
                display: 'flex', alignItems: 'center', gap: 18,
                padding: '20px 24px',
                border: `1px solid rgba(246,162,92,0.35)`,
                borderRadius: 4,
                background: 'rgba(246,162,92,0.04)',
                maxWidth: 520,
              }}>
                <div style={{
                  fontFamily: FONT_DISPLAY,
                  fontSize: 46, color: MOSUN_SAFFRON,
                }}>★</div>
                <div>
                  <div style={{
                    fontFamily: FONT_SANS, fontSize: 10,
                    letterSpacing: '0.28em', color: MOSUN_CREAM_60,
                    textTransform: 'uppercase',
                  }}>Voting Member</div>
                  <div style={{
                    fontFamily: FONT_DISPLAY, fontSize: 22,
                    color: MOSUN_CREAM, marginTop: 4,
                    letterSpacing: '0.04em', textTransform: 'uppercase',
                  }}>The Recording Academy</div>
                  <div style={{
                    fontFamily: FONT_SERIF, fontStyle: 'italic',
                    fontSize: 15, color: MOSUN_CREAM_80, marginTop: 2,
                  }}>Grammy Awards</div>
                </div>
              </div>
            </div>

            <GrainOverlay opacity={0.05}/>
          </div>
        );
      }}
    </Sprite>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 3 — Sound  (13 → 19s)
// ─────────────────────────────────────────────────────────────
function SceneSound({ start, end }) {
  const TAGS = [
    { label: 'POP', x: 180, y: 320, size: 160, rot: -4, delay: 0.3 },
    { label: 'R&B', x: 900, y: 260, size: 180, rot: 3, delay: 0.6 },
    { label: 'ELECTRONIC', x: 220, y: 680, size: 110, rot: 2, delay: 0.9 },
    { label: 'EXPERIMENTAL', x: 720, y: 780, size: 92, rot: -3, delay: 1.2 },
  ];
  return (
    <Sprite start={start} end={end}>
      {({ localTime, duration }) => {
        const t = localTime;
        const exitStart = duration - 0.6;
        const pageFade = t > exitStart ? 1 - Easing.easeInCubic((t - exitStart) / 0.6) : 1;

        // After 3.2s, all tags collapse to center and form the line
        const mergeStart = 3.2;
        const mergeEnd = 4.4;
        const merge = Easing.easeInOutCubic(clamp((t - mergeStart) / (mergeEnd - mergeStart), 0, 1));

        // Final phrase fades in as merge completes
        const phraseOp = Easing.easeOutCubic(clamp((t - 4.2) / 0.7, 0, 1));

        return (
          <div style={{ position: 'absolute', inset: 0, opacity: pageFade }}>
            <SaffronGlow x={960} y={540} radius={900} intensity={0.14}/>
            <Chrome section="Sound" sectionNo="02" total="07"/>

            {/* Floating genre tags */}
            {TAGS.map((tag, i) => {
              const appear = Easing.easeOutCubic(clamp((t - tag.delay) / 0.5, 0, 1));
              // Before merge: original position. Animated position interpolates toward center.
              const cx = 960, cy = 540;
              const x = tag.x + (cx - tag.x - tag.size * 0.3) * merge;
              const y = tag.y + (cy - tag.y - tag.size * 0.2) * merge;
              const scale = (0.9 + 0.1 * appear) * (1 - 0.5 * merge);
              const op = appear * (1 - merge);
              return (
                <div key={tag.label} style={{
                  position: 'absolute',
                  left: x, top: y,
                  fontFamily: FONT_DISPLAY,
                  fontSize: tag.size,
                  color: i === 1 ? MOSUN_SAFFRON : MOSUN_CREAM,
                  letterSpacing: '-0.01em',
                  opacity: op,
                  transform: `rotate(${tag.rot}deg) scale(${scale})`,
                  transformOrigin: '0 0',
                  textTransform: 'uppercase',
                  mixBlendMode: 'normal',
                }}>
                  {tag.label}
                </div>
              );
            })}

            {/* Merged phrase */}
            <div style={{
              position: 'absolute', left: '50%', top: '50%',
              transform: 'translate(-50%, -50%)',
              textAlign: 'center',
              opacity: phraseOp,
              width: 1600,
            }}>
              <div style={{
                fontFamily: FONT_SANS, fontSize: 12,
                letterSpacing: '0.32em', color: MOSUN_CREAM_60,
                textTransform: 'uppercase', marginBottom: 28,
              }}>The Sound</div>
              <div style={{
                fontFamily: FONT_DISPLAY,
                fontSize: 76, color: MOSUN_CREAM,
                lineHeight: 1.1,
                letterSpacing: '-0.01em',
                textTransform: 'uppercase',
              }}>
                One Genre-Breaking
                <br/>
                <span style={{ color: MOSUN_SAFFRON }}>Sonic Rebellion.</span>
              </div>
              <div style={{
                fontFamily: FONT_SERIF, fontStyle: 'italic',
                fontSize: 26, color: MOSUN_CREAM_80,
                marginTop: 32, letterSpacing: '0.02em',
              }}>
                Pop · R&B · Electronic · Experimental
              </div>
            </div>

            <GrainOverlay opacity={0.05}/>
          </div>
        );
      }}
    </Sprite>
  );
}

Object.assign(window, { SceneOpen, SceneBio, SceneSound });
