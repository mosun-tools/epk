// Scene 4 — Discography + Milestones
// Scene 5 — Production Highlights + Awards

// Counting number — animates from 0 to target over dur seconds, then holds.
function CountUp({ to, suffix = '', prefix = '', start = 0, dur = 1.0, decimals = 0 }) {
  const { localTime } = useSprite();
  const t = clamp((localTime - start) / dur, 0, 1);
  const eased = Easing.easeOutCubic(t);
  const v = to * eased;
  return <span>{prefix}{v.toFixed(decimals)}{suffix}</span>;
}

// Chart item — single row showing rank, title, chart name
function ChartRow({ rank, title, chinese, chart, delay, localTime, accent = false }) {
  const appear = Easing.easeOutCubic(clamp((localTime - delay) / 0.6, 0, 1));
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '90px 1fr auto',
      alignItems: 'baseline',
      padding: '18px 0',
      borderBottom: `1px solid rgba(232,230,217,0.14)`,
      opacity: appear,
      transform: `translateX(${(1 - appear) * -16}px)`,
    }}>
      <div style={{
        fontFamily: FONT_DISPLAY,
        fontSize: 44,
        color: accent ? MOSUN_SAFFRON : MOSUN_CREAM,
        letterSpacing: '-0.02em',
      }}>
        {localTime > delay + 0.2 ? rank : '—'}
      </div>
      <div>
        <div style={{
          fontFamily: FONT_DISPLAY, fontSize: 28,
          color: MOSUN_CREAM, textTransform: 'uppercase',
          letterSpacing: '-0.005em',
        }}>{title}</div>
        {chinese && <div style={{
          fontFamily: FONT_SERIF, fontStyle: 'italic',
          fontSize: 18, color: MOSUN_CREAM_80, marginTop: 2,
        }}>{chinese}</div>}
      </div>
      <div style={{
        fontFamily: FONT_SANS, fontSize: 11,
        letterSpacing: '0.22em', textTransform: 'uppercase',
        color: MOSUN_CREAM_60, textAlign: 'right',
      }}>{chart}</div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 4 — Discography  (19 → 28s)
// ─────────────────────────────────────────────────────────────
function SceneDiscography({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      {({ localTime, duration }) => {
        const t = localTime;
        const exitStart = duration - 0.6;
        const pageFade = t > exitStart ? 1 - Easing.easeInCubic((t - exitStart) / 0.6) : 1;

        return (
          <div style={{ position: 'absolute', inset: 0, opacity: pageFade }}>
            <SaffronGlow x={1700} y={200} radius={700} intensity={0.1}/>
            <Chrome section="Discography & Milestones" sectionNo="03" total="07"/>

            {/* Left — big views count */}
            <div style={{
              position: 'absolute', left: 120, top: 200, width: 720,
            }}>
              <div style={{ opacity: Easing.easeOutCubic(clamp(t / 0.5, 0, 1)) }}>
                <Eyebrow>Released Works</Eyebrow>
              </div>
              <div style={{ marginTop: 36 }}>
                <div style={{
                  fontFamily: FONT_DISPLAY,
                  fontSize: 220,
                  color: MOSUN_SAFFRON,
                  letterSpacing: '-0.04em',
                  lineHeight: 1,
                  opacity: Easing.easeOutCubic(clamp((t - 0.3) / 0.6, 0, 1)),
                }}>
                  <CountUp to={9.5} suffix="M+" start={0.4} dur={1.6} decimals={1}/>
                </div>
                <div style={{
                  fontFamily: FONT_SANS, fontSize: 14,
                  letterSpacing: '0.22em', color: MOSUN_CREAM_80,
                  textTransform: 'uppercase', marginTop: 8,
                  opacity: Easing.easeOutCubic(clamp((t - 1.8) / 0.5, 0, 1)),
                }}>
                  Combined MV Views · YouTube
                </div>
              </div>

              {/* Smaller stats */}
              <div style={{
                display: 'grid', gridTemplateColumns: '1fr 1fr',
                gap: '32px 48px', marginTop: 72,
              }}>
                {[
                  { label: 'Top 10 Singles of the Year', val: '#7', sub: '“Nowhere (向你漂泊)” · Qishui Chart', delay: 2.0 },
                  { label: 'KKBOX Mandarin New Release', val: '#3', sub: '“Missed Out (就這麼錯過)”', delay: 2.4 },
                  { label: 'NetEase Cloud Singles', val: '#6', sub: '“Vanity (虛榮到底)” · 999+ comments', delay: 2.8 },
                  { label: 'Freshmusic Awards', val: '13ᵗʰ', sub: 'Nominated', delay: 3.2 },
                ].map((s, i) => {
                  const appear = Easing.easeOutCubic(clamp((t - s.delay) / 0.6, 0, 1));
                  return (
                    <div key={i} style={{
                      opacity: appear,
                      transform: `translateY(${(1 - appear) * 10}px)`,
                      borderTop: `1px solid rgba(232,230,217,0.14)`,
                      paddingTop: 20,
                    }}>
                      <div style={{
                        fontFamily: FONT_SANS, fontSize: 10,
                        letterSpacing: '0.24em', color: MOSUN_CREAM_60,
                        textTransform: 'uppercase',
                      }}>{s.label}</div>
                      <div style={{
                        fontFamily: FONT_DISPLAY, fontSize: 56,
                        color: MOSUN_CREAM, marginTop: 10,
                        letterSpacing: '-0.02em',
                      }}>{s.val}</div>
                      <div style={{
                        fontFamily: FONT_SERIF, fontStyle: 'italic',
                        fontSize: 15, color: MOSUN_CREAM_80, marginTop: 4,
                      }}>{s.sub}</div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right — featured MV card */}
            <div style={{
              position: 'absolute', right: 120, top: 200,
              width: 520,
              opacity: Easing.easeOutCubic(clamp((t - 4.0) / 0.7, 0, 1)),
              transform: `translateY(${(1 - Easing.easeOutCubic(clamp((t - 4.0) / 0.7, 0, 1))) * 18}px)`,
            }}>
              <Eyebrow>Featured Collaboration</Eyebrow>
              <div style={{
                marginTop: 24,
                background: '#0E0E0E',
                border: `1px solid rgba(232,230,217,0.14)`,
                borderRadius: 14, overflow: 'hidden',
              }}>
                {/* MV thumbnail placeholder */}
                <div style={{ position: 'relative' }}>
                  <img src="assets/mv-off-you-go.jpg" alt="慢走不送 · OFF YOU GO"
                    style={{
                      width: 518, height: 280,
                      objectFit: 'cover',
                      display: 'block',
                    }}/>
                  <div style={{
                    position: 'absolute', right: 24, bottom: 24,
                    width: 52, height: 52, borderRadius: '50%',
                    border: `1.5px solid ${MOSUN_SAFFRON}`,
                    background: 'rgba(0,0,0,0.5)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <div style={{
                      width: 0, height: 0,
                      borderLeft: `11px solid ${MOSUN_SAFFRON}`,
                      borderTop: '7px solid transparent',
                      borderBottom: '7px solid transparent',
                      marginLeft: 3,
                    }}/>
                  </div>
                </div>
                <div style={{ padding: '22px 26px' }}>
                  <div style={{
                    fontFamily: FONT_SERIF, fontStyle: 'italic',
                    fontSize: 18, color: MOSUN_CREAM_80,
                  }}>慢走不送 — OFF YOU GO · J.Sheon × Morrison</div>
                  <div style={{
                    display: 'flex', alignItems: 'baseline', gap: 14,
                    marginTop: 14,
                  }}>
                    <div style={{
                      fontFamily: FONT_DISPLAY, fontSize: 44,
                      color: MOSUN_SAFFRON, letterSpacing: '-0.02em',
                    }}>
                      <CountUp to={7.5} suffix="M+" start={4.5} dur={1.2} decimals={1}/>
                    </div>
                    <div style={{
                      fontFamily: FONT_SANS, fontSize: 11,
                      letterSpacing: '0.22em', color: MOSUN_CREAM_60,
                      textTransform: 'uppercase',
                    }}>YouTube Views</div>
                  </div>
                </div>
              </div>
            </div>

            <GrainOverlay opacity={0.05}/>
          </div>
        );
      }}
    </Sprite>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 5 — Production Highlights  (28 → 36s)
// ─────────────────────────────────────────────────────────────
function SceneProduction({ start, end }) {
  const CREDITS = [
    'Jolin Tsai',
    'Shi Shi 孫盛希',
    'J.Sheon',
    'BLACKPINK · Coachella',
    'Steve Aoki',
    'Billboard China',
    'Spaceport Festival',
    'Ultra Taiwan',
    'Golden Melody Awards',
  ];
  const AWARDS = [
    { year: '2025', name: 'Asia Pop Music Awards', credit: 'Jolin Tsai — "Pleasure"' },
    { year: '2025', name: 'Lavender Music Award', credit: 'Jolin Tsai — "DIY"' },
    { year: '2025', name: 'Including But Not Limited To', credit: 'Pei-Yu Hung 洪佩瑜' },
  ];

  return (
    <Sprite start={start} end={end}>
      {({ localTime, duration }) => {
        const t = localTime;
        const exitStart = duration - 0.6;
        const pageFade = t > exitStart ? 1 - Easing.easeInCubic((t - exitStart) / 0.6) : 1;

        return (
          <div style={{ position: 'absolute', inset: 0, opacity: pageFade }}>
            <SaffronGlow x={400} y={200} radius={700} intensity={0.1}/>
            <Chrome section="Production Highlights" sectionNo="05" total="07"/>

            {/* Heading */}
            <div style={{
              position: 'absolute', left: 120, top: 180, width: 1200,
            }}>
              <div style={{ opacity: Easing.easeOutCubic(clamp(t / 0.5, 0, 1)) }}>
                <Eyebrow>Production Credits</Eyebrow>
              </div>
              <div style={{
                fontFamily: FONT_DISPLAY, fontSize: 68,
                color: MOSUN_CREAM, marginTop: 22,
                letterSpacing: '-0.01em', lineHeight: 1.08,
                maxWidth: 1100, textTransform: 'uppercase',
              }}>
                <RevealText
                  text="Grammy-recognized production behind the stages you already know."
                  size={68} font={FONT_DISPLAY} color={MOSUN_CREAM}
                  staggerMs={60} entryDur={500} startAt={0.2}
                  lineHeight={1.08} letterSpacing="-0.01em"
                />
              </div>
            </div>

            {/* Marquee of credits — scrolls, then stops with BLACKPINK centered */}
            {(() => {
              const fadeIn = Easing.easeOutCubic(clamp((t - 2.0) / 0.5, 0, 1));
              const scrollStart = 2.0;
              const scrollDur = 3.2;   // scroll for 3.2s then ease to stop
              const stopAt = scrollStart + scrollDur;
              const hiIdx = CREDITS.indexOf('BLACKPINK · Coachella');
              const GAP = 72;
              // Average char width at 72px ~ 38px; estimate widths per credit
              const widths = CREDITS.map(c => c.length * 38 + 8 + GAP);
              // Position of highlighted credit's center within one full cycle
              let cumLeft = 0;
              for (let i = 0; i < hiIdx; i++) cumLeft += widths[i];
              const hiCenter = cumLeft + widths[hiIdx] / 2;

              // Distance needed so the highlight lands at viewport center (960)
              const targetX = 960 - hiCenter;
              // Start far off to right so marquee scrolls leftward into place
              const startX = targetX + 1600;

              let translateX;
              if (t < scrollStart) translateX = startX;
              else if (t < stopAt) {
                const p = (t - scrollStart) / scrollDur;
                const eased = Easing.easeOutCubic(p);
                translateX = startX + (targetX - startX) * eased;
              } else {
                translateX = targetX;
              }

              const locked = t >= stopAt;
              const lockT = Math.max(0, t - stopAt);
              const pulse = locked ? (0.7 + 0.3 * Math.sin(lockT * 3)) : 0;

              return (
                <div style={{
                  position: 'absolute', left: 0, right: 0, top: 500,
                  overflow: 'hidden', opacity: fadeIn,
                }}>
                  {/* center pointer that fades in on lock */}
                  <div style={{
                    position: 'absolute', left: 960, top: -8, bottom: -8,
                    width: 0,
                    borderLeft: `1px dashed rgba(246,162,92,${0.5 * pulse})`,
                    pointerEvents: 'none',
                  }}/>
                  <div style={{
                    display: 'flex', gap: GAP,
                    transform: `translateX(${translateX}px)`,
                    whiteSpace: 'nowrap',
                    fontFamily: FONT_DISPLAY,
                    fontSize: 72,
                    letterSpacing: '-0.01em',
                    textTransform: 'uppercase',
                    lineHeight: 1,
                  }}>
                    {CREDITS.map((c, i) => {
                      const isHi = i === hiIdx;
                      return (
                        <div key={i} style={{
                          color: isHi
                            ? MOSUN_SAFFRON
                            : (locked ? MOSUN_CREAM_60 : MOSUN_CREAM),
                          display: 'flex', alignItems: 'center', gap: GAP,
                          textShadow: isHi && locked
                            ? `0 0 ${20 + 12 * pulse}px rgba(246,162,92,${0.55 * pulse})`
                            : 'none',
                          transform: isHi && locked
                            ? `scale(${1 + 0.04 * pulse})`
                            : 'none',
                          transformOrigin: 'center',
                          transition: 'color 400ms ease',
                        }}>
                          <span>{c}</span>
                          <span style={{
                            width: 8, height: 8, borderRadius: '50%',
                            background: MOSUN_SAFFRON, flexShrink: 0,
                          }}/>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })()}

            {/* Awards row */}
            <div style={{
              position: 'absolute', left: 120, right: 120, top: 720,
              display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)',
              gap: 48,
            }}>
              {AWARDS.map((a, i) => {
                const d = 3.2 + i * 0.4;
                const appear = Easing.easeOutCubic(clamp((t - d) / 0.6, 0, 1));
                return (
                  <div key={i} style={{
                    opacity: appear,
                    transform: `translateY(${(1 - appear) * 14}px)`,
                    borderTop: `1px solid rgba(246,162,92,0.4)`,
                    paddingTop: 20,
                  }}>
                    <div style={{
                      display: 'flex', gap: 12, alignItems: 'baseline',
                      fontFamily: FONT_SANS, fontSize: 11,
                      letterSpacing: '0.24em', color: MOSUN_SAFFRON,
                      textTransform: 'uppercase',
                    }}>
                      <span>★ {a.year}</span>
                      <span style={{ color: MOSUN_CREAM_60 }}>Award</span>
                    </div>
                    <div style={{
                      fontFamily: FONT_DISPLAY, fontSize: 28,
                      color: MOSUN_CREAM, marginTop: 10,
                      textTransform: 'uppercase',
                      letterSpacing: '-0.005em',
                    }}>{a.name}</div>
                    <div style={{
                      fontFamily: FONT_SERIF, fontStyle: 'italic',
                      fontSize: 17, color: MOSUN_CREAM_80, marginTop: 6,
                    }}>{a.credit}</div>
                  </div>
                );
              })}
            </div>

            <GrainOverlay opacity={0.05}/>
          </div>
        );
      }}
    </Sprite>
  );
}

Object.assign(window, { SceneDiscography, SceneProduction, CountUp });
