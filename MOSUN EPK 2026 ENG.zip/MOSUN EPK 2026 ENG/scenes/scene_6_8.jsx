// Scene 6 — Brand Partners
// Scene 7 — Market Differentiation (3 pillars)
// Scene 8 — Vision + Contact outro

const BRANDS = [
  'JUSTINXX × NIKE',
  'COACH',
  'Acne Studios',
  'Devialet',
  'Isart.Gallery',
  'Playtronica',
  "L'Oréal 萊雅",
];

// ─────────────────────────────────────────────────────────────
// SCENE 6 — Brand Partners (36 → 42s)
// ─────────────────────────────────────────────────────────────
function SceneBrands({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      {({ localTime, duration }) => {
        const t = localTime;
        const exitStart = duration - 0.6;
        const pageFade = t > exitStart ? 1 - Easing.easeInCubic((t - exitStart) / 0.6) : 1;

        return (
          <div style={{ position: 'absolute', inset: 0, opacity: pageFade }}>
            <SaffronGlow x={1500} y={900} radius={800} intensity={0.12}/>
            <Chrome section="Brand Partners" sectionNo="06" total="07"/>

            {/* Heading */}
            <div style={{
              position: 'absolute', left: 120, top: 200, width: 700,
            }}>
              <div style={{ opacity: Easing.easeOutCubic(clamp(t / 0.5, 0, 1)) }}>
                <Eyebrow>Brand Partners</Eyebrow>
              </div>
              <div style={{ marginTop: 32 }}>
                <RevealText
                  text="An aesthetic creator — not a fashion-forward artist."
                  size={64} font={FONT_DISPLAY} color={MOSUN_CREAM}
                  staggerMs={70} entryDur={500} startAt={0.2}
                  lineHeight={1.08} letterSpacing="-0.01em"
                />
              </div>
              <div style={{
                marginTop: 28,
                opacity: Easing.easeOutCubic(clamp((t - 2.4) / 0.6, 0, 1)),
                fontFamily: FONT_SERIF, fontStyle: 'italic',
                fontSize: 22, color: MOSUN_CREAM_80, maxWidth: 520,
                lineHeight: 1.4,
              }}>
                Music videos, photography, cover art, styling, color — every element locks into a single coherent MOSUN worldview.
              </div>
            </div>

            {/* Brand grid right */}
            <div style={{
              position: 'absolute', right: 120, top: 200,
              width: 780,
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: 0,
            }}>
              {BRANDS.map((b, i) => {
                const d = 1.2 + i * 0.18;
                const appear = Easing.easeOutCubic(clamp((t - d) / 0.5, 0, 1));
                return (
                  <div key={i} style={{
                    opacity: appear,
                    transform: `translateY(${(1 - appear) * 16}px)`,
                    padding: '40px 28px',
                    borderRight: i % 2 === 0 ? `1px solid rgba(232,230,217,0.14)` : 'none',
                    borderBottom: `1px solid rgba(232,230,217,0.14)`,
                    minHeight: 140,
                    display: 'flex', flexDirection: 'column', justifyContent: 'center',
                  }}>
                    <div style={{
                      fontFamily: FONT_SANS, fontSize: 10,
                      letterSpacing: '0.32em', color: MOSUN_CREAM_60,
                      textTransform: 'uppercase', marginBottom: 10,
                    }}>
                      No. {String(i + 1).padStart(2, '0')}
                    </div>
                    <div style={{
                      fontFamily: FONT_DISPLAY, fontSize: 32,
                      color: i % 3 === 1 ? MOSUN_SAFFRON : MOSUN_CREAM,
                      textTransform: 'uppercase',
                      letterSpacing: '-0.005em', lineHeight: 1.1,
                    }}>{b}</div>
                  </div>
                );
              })}
            </div>

            <GrainOverlay opacity={0.05}/>
          </div>
        );
      }}
    </Sprite>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 7 — Market Differentiation (42 → 52s)
// ─────────────────────────────────────────────────────────────
function SceneDifferentiation({ start, end }) {
  const PILLARS = [
    {
      num: 'i',
      eyebrow: 'A New Sonic Language',
      title: 'Modular Synthesis × Mandarin R&B',
      body: 'One of the few Mandarin artists building a creative process around modular synthesizers — fusing electronic texture with the emotional depth of R&B.',
    },
    {
      num: 'ii',
      eyebrow: 'Depth Without Pretense',
      title: 'Honest. Introspective. Still Pop.',
      body: 'Lyrics that don\'t hide in metaphor. Raw, precise, and built to hit at 3AM — vulnerability, dependency, self-examination.',
    },
    {
      num: 'iii',
      eyebrow: 'A Fully Integrated Aesthetic',
      title: 'Brand-Level Visual Control',
      body: 'Music videos, photography, cover art, styling, color — every element locks into a single coherent MOSUN worldview.',
    },
  ];

  return (
    <Sprite start={start} end={end}>
      {({ localTime, duration }) => {
        const t = localTime;
        const exitStart = duration - 0.6;
        const pageFade = t > exitStart ? 1 - Easing.easeInCubic((t - exitStart) / 0.6) : 1;

        return (
          <div style={{ position: 'absolute', inset: 0, opacity: pageFade }}>
            <SaffronGlow x={960} y={540} radius={1000} intensity={0.1}/>
            <Chrome section="Market Differentiation" sectionNo="07" total="07"/>

            {/* Heading */}
            <div style={{
              position: 'absolute', left: 120, top: 180, width: 1200,
              opacity: Easing.easeOutCubic(clamp(t / 0.6, 0, 1)),
            }}>
              <Eyebrow>Why MOSUN</Eyebrow>
              <div style={{
                fontFamily: FONT_DISPLAY, fontSize: 64,
                color: MOSUN_CREAM, marginTop: 22,
                letterSpacing: '-0.01em', lineHeight: 1.05,
                textTransform: 'uppercase',
                maxWidth: 1400,
              }}>
                Three things no one else in C-Pop
                <br/>
                is <span style={{ color: MOSUN_SAFFRON }}>DOING AT ONCE.</span>
              </div>
            </div>

            {/* Three pillars */}
            <div style={{
              position: 'absolute', left: 120, right: 120, top: 460,
              display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)',
              gap: 56,
            }}>
              {PILLARS.map((p, i) => {
                const d = 1.4 + i * 0.5;
                const appear = Easing.easeOutCubic(clamp((t - d) / 0.7, 0, 1));
                return (
                  <div key={i} style={{
                    opacity: appear,
                    transform: `translateY(${(1 - appear) * 24}px)`,
                    borderTop: `1px solid ${MOSUN_SAFFRON}`,
                    paddingTop: 28,
                  }}>
                    <div style={{
                      fontFamily: FONT_DECOR,
                      fontSize: 120, color: MOSUN_SAFFRON,
                      lineHeight: 0.9, letterSpacing: '-0.02em',
                      textTransform: 'lowercase',
                    }}>{p.num}</div>
                    <div style={{
                      fontFamily: FONT_SANS, fontSize: 11,
                      letterSpacing: '0.28em', color: MOSUN_CREAM_60,
                      textTransform: 'uppercase', marginTop: 24,
                    }}>{p.eyebrow}</div>
                    <div style={{
                      fontFamily: FONT_DISPLAY, fontSize: 30,
                      color: MOSUN_CREAM, marginTop: 12,
                      letterSpacing: '-0.005em', lineHeight: 1.15,
                      textTransform: 'uppercase',
                    }}>{p.title}</div>
                    <div style={{
                      fontFamily: FONT_SANS, fontSize: 16,
                      color: MOSUN_CREAM_80, marginTop: 18,
                      lineHeight: 1.5, maxWidth: 380,
                    }}>{p.body}</div>
                  </div>
                );
              })}
            </div>

            <GrainOverlay opacity={0.05}/>
          </div>
        );
      }}
    </Sprite>
  );
}

// ─────────────────────────────────────────────────────────────
// SCENE 8 — Vision + Contact outro (52 → 62s)
// ─────────────────────────────────────────────────────────────
function SceneVision({ start, end }) {
  return (
    <Sprite start={start} end={end}>
      {({ localTime, duration }) => {
        const t = localTime;

        // Vision statement 0→5s
        // Contact card appears 4.5s
        // Final logo lockup 6.5s

        return (
          <div style={{ position: 'absolute', inset: 0 }}>
            <SaffronGlow x={960} y={540} radius={1200} intensity={0.18}/>

            {/* Giant faint mark behind */}
            <div style={{
              position: 'absolute', left: '50%', top: '50%',
              transform: `translate(-50%, -50%) scale(${1 + 0.06 * Easing.easeOutCubic(clamp(t/6, 0, 1))})`,
              opacity: 0.06,
              pointerEvents: 'none',
            }}>
              <img src="assets/mark-orange-on-black.png" style={{ width: 1600, height: 'auto' }}/>
            </div>

            {/* Vision phase */}
            <div style={{
              position: 'absolute', left: '50%', top: '50%',
              transform: 'translate(-50%, -50%)',
              textAlign: 'center', width: 1500,
              opacity: t < 5.5 ? 1 : 1 - Easing.easeInCubic(clamp((t - 5.5) / 1.0, 0, 1)),
            }}>
              <div style={{ opacity: Easing.easeOutCubic(clamp(t / 0.6, 0, 1)) }}>
                <Eyebrow>Vision</Eyebrow>
              </div>
              <div style={{ marginTop: 40 }}>
                <RevealText
                  text="To carve out a permanent place for Mandarin music on the world's biggest stages."
                  size={72} font={FONT_DISPLAY} color={MOSUN_CREAM}
                  staggerMs={100} entryDur={700} startAt={0.4}
                  lineHeight={1.12} letterSpacing="-0.01em"
                />
              </div>
              <div style={{
                marginTop: 36,
                fontFamily: FONT_DISPLAY,
                fontSize: 28,
                letterSpacing: '0.2em',
                color: MOSUN_SAFFRON,
                textTransform: 'uppercase',
                opacity: Easing.easeOutCubic(clamp((t - 2.8) / 0.7, 0, 1)),
              }}>
                Grammy Awards · Coachella · Beyond
              </div>
              <div style={{
                marginTop: 40,
                fontFamily: FONT_SERIF, fontStyle: 'italic',
                fontSize: 22, color: MOSUN_CREAM_80,
                maxWidth: 880, margin: '40px auto 0',
                lineHeight: 1.5,
                opacity: Easing.easeOutCubic(clamp((t - 3.6) / 0.8, 0, 1)),
              }}>
                Real power comes from honesty and creation — never from chasing the market. A song for everyone still dreaming deep into the night.
              </div>
            </div>

            {/* Final lockup — fades in after vision fades out */}
            <div style={{
              position: 'absolute', left: '50%', top: '50%',
              transform: 'translate(-50%, -50%)',
              textAlign: 'center', width: 1200,
              opacity: Easing.easeOutCubic(clamp((t - 6.0) / 0.9, 0, 1)),
            }}>
              <div style={{
                fontFamily: FONT_DISPLAY,
                fontSize: 220, color: MOSUN_CREAM,
                letterSpacing: '0.32em', textTransform: 'uppercase',
                paddingLeft: '0.32em',
                textShadow: '0 0 80px rgba(246,162,92,0.25)',
              }}>
                MOSUN
              </div>
              <div style={{
                margin: '8px auto 0',
                height: 1, width: 220,
                background: MOSUN_SAFFRON,
              }}/>
              <div style={{
                marginTop: 40,
                display: 'flex', justifyContent: 'center', gap: 72,
                fontFamily: FONT_SANS, fontSize: 16,
                letterSpacing: '0.12em', color: MOSUN_CREAM,
                textTransform: 'uppercase',
              }}>
                <div>
                  <div style={{
                    fontSize: 10, letterSpacing: '0.32em', color: MOSUN_CREAM_60, marginBottom: 8,
                  }}>Email</div>
                  <div style={{ color: MOSUN_SAFFRON }}>i@mosun.cool</div>
                </div>
                <div>
                  <div style={{
                    fontSize: 10, letterSpacing: '0.32em', color: MOSUN_CREAM_60, marginBottom: 8,
                  }}>Instagram</div>
                  <div style={{ color: MOSUN_SAFFRON }}>@morrisonma</div>
                </div>
              </div>
              <div style={{
                marginTop: 48,
                fontFamily: FONT_SANS, fontSize: 10,
                letterSpacing: '0.24em', color: MOSUN_CREAM_40,
                textTransform: 'uppercase',
              }}>
                © GENSUN LTD. 更日未來有限公司 · Internal Use Only
              </div>
            </div>

            <GrainOverlay opacity={0.06}/>
          </div>
        );
      }}
    </Sprite>
  );
}

Object.assign(window, { SceneBrands, SceneDifferentiation, SceneVision, SceneOnStage });

// ─────────────────────────────────────────────────────────────
// SCENE — On Stage (photo showcase)
// ─────────────────────────────────────────────────────────────
// 5 frames in an asymmetric editorial grid. Drop real images into
// /assets/stage-{1..5}.jpg and they'll appear; until then, placeholder.
function SceneOnStage({ start, end }) {
  // 1920×1080 canvas. Title/eyebrow occupy top-right and bottom-left;
  // photos fill the remaining area in an editorial mosaic.
  const FRAMES = [
    // Landscape hero — left half
    { src: 'assets/stage-3.jpg', label: 'HEADLINE',   loc: 'MOSUN Live',  yr: '2024', x: 120,  y: 220, w: 820, h: 780 },
    // Three portraits — right half
    { src: 'assets/stage-1.jpg', label: 'SILHOUETTE', loc: 'Taipei',      yr: '2024', x: 970,  y: 220, w: 260, h: 780 },
    { src: 'assets/stage-2.jpg', label: 'CROWD',      loc: 'Guangzhou',   yr: '2025', x: 1250, y: 220, w: 260, h: 780 },
    { src: 'assets/stage-4.jpg', label: 'ENCORE',     loc: 'Live House',  yr: '2025', x: 1530, y: 220, w: 260, h: 780 },
  ];

  return (
    <Sprite start={start} end={end}>
      {({ localTime, duration }) => {
        const t = localTime;
        const exitStart = duration - 0.6;
        const pageFade = t > exitStart ? 1 - Easing.easeInCubic((t - exitStart) / 0.6) : 1;

        return (
          <div style={{ position: 'absolute', inset: 0, opacity: pageFade }}>
            <SaffronGlow x={200} y={1000} radius={700} intensity={0.08}/>
            <Chrome section="On Stage" sectionNo="04" total="07"/>

            {/* Eyebrow + headline, top-left (compact so photos have room) */}
            <div style={{
              position: 'absolute', left: 120, top: 100, width: 900,
              opacity: Easing.easeOutCubic(clamp((t - 0.1) / 0.6, 0, 1)),
              transform: `translateY(${(1 - Easing.easeOutCubic(clamp((t - 0.1) / 0.6, 0, 1))) * 16}px)`,
            }}>
              <Eyebrow>Live Archive</Eyebrow>
              <div style={{
                fontFamily: FONT_DISPLAY, fontSize: 64,
                color: MOSUN_CREAM, lineHeight: 0.95,
                letterSpacing: '-0.02em', textTransform: 'uppercase',
                marginTop: 14,
              }}>
                On Stage<span style={{ color: MOSUN_SAFFRON }}>.</span>
                <span style={{
                  fontFamily: FONT_SERIF, fontStyle: 'italic',
                  fontSize: 22, color: MOSUN_CREAM_80,
                  marginLeft: 24, letterSpacing: 0, textTransform: 'none',
                  verticalAlign: 'middle',
                }}>
                  Recent performances — from festival mains to intimate rooms.
                </span>
              </div>
            </div>

            {/* Frames */}
            {FRAMES.map((f, i) => {
              const d = 0.4 + i * 0.18;
              const appear = Easing.easeOutCubic(clamp((t - d) / 0.7, 0, 1));
              return (
                <div key={i} style={{
                  position: 'absolute',
                  left: f.x, top: f.y, width: f.w, height: f.h,
                  opacity: appear,
                  transform: `translateY(${(1 - appear) * 24}px)`,
                }}>
                  <div style={{
                    position: 'relative', width: '100%', height: '100%',
                    overflow: 'hidden',
                    background: '#0E0E0E',
                    boxShadow: '0 14px 44px rgba(0,0,0,0.55), 0 0 0 1px rgba(232,230,217,0.08)',
                  }}>
                    <img src={f.src + '?v=3'}
                      onError={(e) => {
                        e.currentTarget.style.visibility = 'hidden';
                      }}
                      style={{
                        width: '100%', height: '100%', objectFit: 'cover',
                        display: 'block', position: 'relative', zIndex: 1,
                        filter: 'contrast(1.02) saturate(1.02)',
                      }}/>
                    {/* placeholder crosshair visible when image fails */}
                    <div style={{
                      position: 'absolute', inset: 0,
                      display: 'flex', flexDirection: 'column',
                      alignItems: 'center', justifyContent: 'center',
                      gap: 12,
                      pointerEvents: 'none', zIndex: 0,
                      background: 'repeating-linear-gradient(135deg, rgba(246,162,92,0.04) 0 12px, transparent 12px 24px), #0E0E0E',
                    }}>
                      <div style={{
                        width: 28, height: 28,
                        border: `1px solid ${MOSUN_SAFFRON}`, borderRadius: '50%',
                        position: 'relative',
                      }}>
                        <div style={{
                          position: 'absolute', left: '50%', top: -12, bottom: -12,
                          width: 1, background: MOSUN_SAFFRON, opacity: 0.6,
                        }}/>
                        <div style={{
                          position: 'absolute', top: '50%', left: -12, right: -12,
                          height: 1, background: MOSUN_SAFFRON, opacity: 0.6,
                        }}/>
                      </div>
                      <div style={{
                        fontFamily: FONT_SANS, fontSize: 10,
                        letterSpacing: '0.3em', color: MOSUN_SAFFRON,
                        textTransform: 'uppercase', opacity: 0.85,
                      }}>
                        {f.src.split('/').pop()}
                      </div>
                      <div style={{
                        fontFamily: FONT_SERIF, fontStyle: 'italic',
                        fontSize: 12, color: MOSUN_CREAM_60,
                      }}>
                        drop photo here
                      </div>
                    </div>
                    {/* saffron corner brackets */}
                    {[[0,0],[1,0],[0,1],[1,1]].map(([x,y],k)=>(
                      <span key={k} style={{
                        position: 'absolute',
                        left: x ? 'auto' : 8, right: x ? 8 : 'auto',
                        top:  y ? 'auto' : 8, bottom: y ? 8 : 'auto',
                        width: 14, height: 14,
                        borderLeft:  x ? 'none' : `1.5px solid ${MOSUN_SAFFRON}`,
                        borderRight: x ? `1.5px solid ${MOSUN_SAFFRON}` : 'none',
                        borderTop:   y ? 'none' : `1.5px solid ${MOSUN_SAFFRON}`,
                        borderBottom:y ? `1.5px solid ${MOSUN_SAFFRON}` : 'none',
                        mixBlendMode: 'screen', zIndex: 2,
                      }}/>
                    ))}
                    {/* caption bar */}
                    <div style={{
                      position: 'absolute', left: 14, right: 14, bottom: 12,
                      display: 'flex', justifyContent: 'space-between',
                      alignItems: 'baseline',
                      fontFamily: FONT_SANS, fontSize: 10,
                      letterSpacing: '0.28em', textTransform: 'uppercase',
                      color: MOSUN_SAFFRON,
                      textShadow: '0 1px 2px rgba(0,0,0,0.7)', zIndex: 2,
                    }}>
                      <span>{String(i+1).padStart(2,'0')} · {f.label}</span>
                      <span style={{ color: 'rgba(232,230,217,0.85)' }}>
                        {f.loc} · {f.yr}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}

            <GrainOverlay opacity={0.06}/>
          </div>
        );
      }}
    </Sprite>
  );
}
