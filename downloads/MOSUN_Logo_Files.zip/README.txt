MOSUN — logo files

MOSUN_mark_*        the monogram mark
MOSUN_wordmark_*    MOSUN set in Prospec, outlined

warm-white (#F4EFE0) on dark backgrounds and photos; black (#000000) on light backgrounds.
Keep clear space around the mark equal to its height. Never stretch, recolour, outline or add a shadow.
Artist name in running text: MOSUN, always in capitals.
